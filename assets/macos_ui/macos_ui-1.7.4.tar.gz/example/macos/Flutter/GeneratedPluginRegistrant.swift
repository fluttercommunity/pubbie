//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import macos_ui

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  MacOSUiPlugin.register(with: registry.registrar(forPlugin: "MacOSUiPlugin"))
}
